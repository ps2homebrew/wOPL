/*
  Copyright 2009, Ifcaro & volca
  Licenced under Academic Free License version 3.0
  Review OpenUsbLd README & LICENSE files for further details.
*/

#include "include/opl.h"
#include "include/util.h"
#include "include/ioman.h"
#include "include/sound.h"
#include <string.h>

// FIXME: We should not need this function.
//        Use newlib's 'stat' to get GMT time.
#define NEWLIB_PORT_AWARE
#include <fileXio_rpc.h> // iox_stat_t, fileXioGetStat
int configGetStat(config_set_t *configSet, iox_stat_t *stat);

static u32 currentUID = 0;
static config_set_t configFiles[CONFIG_INDEX_COUNT];
static char legacyNetConfigPath[256] = "mc?:SYS-CONF/IPCONFIG.DAT";
static const char *configFilenames[CONFIG_INDEX_COUNT] = {
    "conf_uopl.cfg",
    "conf_last.cfg",
    "conf_apps.cfg",
    "conf_network.cfg",
    "conf_game.cfg",
};

static int strToColor(const char *string, unsigned char *color)
{
    int cnt = 0, n = 0;
    color[0] = 0;
    color[1] = 0;
    color[2] = 0;

    if (!string || !*string)
        return 0;
    if (string[0] != '#')
        return 0;

    string++;

    while (*string) {
        int fh = fromHex(*string);
        if (fh >= 0) {
            color[n] = color[n] * 16 + fh;
        } else {
            break;
        }

        // Two characters per color
        if (cnt == 1) {
            cnt = 0;
            n++;
        } else {
            cnt++;
        }

        string++;
    }

    return 1;
}

/// true if given a whitespace character
int isWS(char c)
{
    return c == ' ' || c == '\t';
}

static int splitAssignment(char *line, char *key, size_t keymax, char *val, size_t valmax)
{
    if (!line || !key || !val || keymax == 0 || valmax == 0) {
        LOG("CONFIG Error: Invalid parameters to splitAssignment\n");
        return 0;
    }

    // Initialize key and val to empty strings
    key[0] = '\0';
    val[0] = '\0';

    // skip whitespace
    for (; line && isWS(*line); ++line)
        ;

    if (!line || *line == '\0')
        return 0;

    // find "=".
    // If found, the text before is key, after is val.
    // Otherwise malformed string is encountered
    char *eqpos = strchr(line, '=');

    if (eqpos) {
        // copy the name and the value
        size_t keylen = min(keymax - 1, (size_t)(eqpos - line));
        
        if (keylen > 0) {
            strncpy(key, line, keylen);
            key[keylen] = '\0';
        }

        eqpos++;

        size_t linelen = strlen(line);
        size_t eqposOffset = (size_t)(eqpos - line);
        
        if (eqposOffset <= linelen) {
            size_t vallen = min(valmax - 1, linelen - eqposOffset);
            if (vallen > 0) {
                strncpy(val, eqpos, vallen);
                val[vallen] = '\0';
            }
        }
    }

    return (eqpos != NULL);
}

static int parsePrefix(char *line, char *prefix)
{
    // find "=".
    // If found, the text before is key, after is val.
    // Otherwise malformed string is encountered
    char *colpos = strchr(line, ':');

    if (colpos && colpos != line) {
        // copy the name and the value
        strncpy(prefix, line, colpos - line);
        prefix[colpos - line] = 0;

        return 1;
    } else {
        return 0;
    }
}

static int configKeyValidate(const char *key)
{
    if (strlen(key) == 0)
        return 0;

    return !strchr(key, '=');
}

static struct config_value_t *allocConfigItem(const char *key, const char *val)
{
    struct config_value_t *it = (struct config_value_t *)malloc(sizeof(struct config_value_t));
    if (!it) {
        LOG("CONFIG Error: Failed to allocate memory for config item\n");
        return NULL;
    }
    
    if (key && val) {
        strncpy(it->key, key, sizeof(it->key) - 1);
        it->key[sizeof(it->key) - 1] = '\0';
        strncpy(it->val, val, sizeof(it->val) - 1);
        it->val[sizeof(it->val) - 1] = '\0';
    } else {
        if (key)
            strncpy(it->key, key, sizeof(it->key) - 1);
        else
            it->key[0] = '\0';
        
        it->key[sizeof(it->key) - 1] = '\0';
        
        if (val)
            strncpy(it->val, val, sizeof(it->val) - 1);
        else
            it->val[0] = '\0';
            
        it->val[sizeof(it->val) - 1] = '\0';
    }
    
    it->next = NULL;
    return it;
}

/// Low level key addition. Does not check for uniqueness.
static void addConfigValue(config_set_t *configSet, const char *key, const char *val)
{
    if (!configSet) {
        LOG("CONFIG Error: NULL config set in addConfigValue\n");
        return;
    }
    
    if (!key || !val) {
        LOG("CONFIG Error: NULL key or value in addConfigValue\n");
        return;
    }

    struct config_value_t *item = allocConfigItem(key, val);
    if (!item) {
        LOG("CONFIG Error: Failed to allocate config item in addConfigValue\n");
        return;
    }

    if (!configSet->tail) {
        configSet->head = item;
        configSet->tail = configSet->head;
    } else {
        configSet->tail->next = item;
        configSet->tail = configSet->tail->next;
    }
}

static struct config_value_t *getConfigItemForName(config_set_t *configSet, const char *name)
{
    struct config_value_t *val = configSet->head;

    while (val) {
        if (strncmp(val->key, name, sizeof(val->key)) == 0)
            break;

        val = val->next;
    }

    return val;
}

static char cfgDevice[128];

char *configGetDir(void)
{
char *configGetDir(void)
{
    static char path[256];

    // Initialize path to empty string for safety
    path[0] = '\0';

    if (cfgDevice[0] != '\0') {
        if (!strncmp(cfgDevice, "mc", 2))
            snprintf(path, sizeof(path) - 1, "mc%d:OPL/", getmcID() & 1);
        else
            snprintf(path, sizeof(path) - 1, "%s", cfgDevice);
    } else {
        LOG("CONFIG Warning: cfgDevice is empty in configGetDir\n");
        snprintf(path, sizeof(path) - 1, "mc%d:OPL/", getmcID() & 1);
    }

    // Ensure null termination
    path[sizeof(path) - 1] = '\0';
    
    return path;
}
{
    snprintf(cfgDevice, sizeof(cfgDevice), prefix);
}

void configInit(char *prefix)
{
    char path[256];
    int i;

    if (prefix)
        snprintf(legacyNetConfigPath, sizeof(legacyNetConfigPath), "%s/IPCONFIG.DAT", prefix);
    else
        prefix = gBaseMCDir;

    for (i = 0; i < CONFIG_INDEX_COUNT; i++) {
        snprintf(path, sizeof(path), "%s/%s", prefix, configFilenames[i]);
        configAlloc(1 << i, &configFiles[i], path);
    }

    configPrepareNotifications(prefix);
}

void configSetMove(char *prefix)
{
    char path[256];
    int i;

    if (prefix)
        snprintf(legacyNetConfigPath, sizeof(legacyNetConfigPath), "%s/IPCONFIG.DAT", prefix);
    else
        prefix = gBaseMCDir;

    for (i = 0; i < CONFIG_INDEX_COUNT; i++) {
        snprintf(path, sizeof(path), "%s/%s", prefix, configFilenames[i]);
        configMove(&configFiles[i], path);
    }

    configPrepareNotifications(prefix);
}

void configEnd()
{
    int index = 0;
    while (index < CONFIG_INDEX_COUNT) {
        config_set_t *configSet = &configFiles[index];

        configClear(configSet);
        free(configSet->filename);
        configSet->filename = NULL;
        index++;
    }
}
config_set_t *configAlloc(int type, config_set_t *configSet, char *fileName)
{
    if (!configSet) {
        configSet = (config_set_t *)malloc(sizeof(config_set_t));
        if (!configSet) {
            LOG("CONFIG Error: Failed to allocate memory for config set\n");
            return NULL;
        }
    }

    configSet->uid = ++currentUID;
    configSet->type = type;
    configSet->head = NULL;
    configSet->tail = NULL;
    configSet->filename = NULL;
    
    if (fileName) {
        int length = strlen(fileName) + 1;
        configSet->filename = (char *)malloc(length * sizeof(char));
        if (!configSet->filename) {
            LOG("CONFIG Error: Failed to allocate memory for filename\n");
            if (configSet)
                free(configSet);
            return NULL;
        }
        memcpy(configSet->filename, fileName, length);
    }
    
    configSet->modified = 0;
    return configSet;
}
}
void configMove(config_set_t *configSet, const char *fileName)
{
    if (!configSet || !fileName) {
        LOG("CONFIG Error: NULL parameters in configMove\n");
        return;
    }
    
    int length = strlen(fileName) + 1;
    char *newFilename = realloc(configSet->filename, length);
    
    if (!newFilename) {
        LOG("CONFIG Error: Failed to reallocate memory for filename\n");
        return;
    }
    
    configSet->filename = newFilename;
    memcpy(configSet->filename, fileName, length);
}
}

void configFree(config_set_t *configSet)
{
    configClear(configSet);
    free(configSet->filename);
    free(configSet);
}

config_set_t *configGetByType(int type)
{
    int index = 0;
    while (index < CONFIG_INDEX_COUNT) {
        config_set_t *configSet = &configFiles[index];

        if (configSet->type == type)
            return configSet;
        index++;
    }
    return NULL;
}

int configSetStr(config_set_t *configSet, const char *key, const char *value)
{
    if (!configSet) {
        LOG("CONFIG Error: NULL config set in configSetStr\n");
        return 0;
    }
    
    if (!key || !value) {
        LOG("CONFIG Error: NULL key or value in configSetStr\n");
        return 0;
    }
    
    if (!configKeyValidate(key))
        return 0;

    struct config_value_t *it = getConfigItemForName(configSet, key);

    if (it) {
        if (strncmp(it->val, value, sizeof(it->val)) != 0) {
            strncpy(it->val, value, sizeof(it->val) - 1);
            it->val[sizeof(it->val) - 1] = '\0';
            if (it->key[0] != '#')
                configSet->modified = 1;
        }
    } else {
        addConfigValue(configSet, key, value);
        if (key[0] != '#')
            configSet->modified = 1;
    }

    return 1;
}

// sets the value to point to the value str in the config. Do not overwrite - it will overwrite the string in config
int configGetStr(config_set_t *configSet, const char *key, const char **value)
{
    if (!configKeyValidate(key))
        return 0;

    struct config_value_t *it = getConfigItemForName(configSet, key);

    if (it) {
        *value = it->val;
        return 1;
    } else
        return 0;
}

int configGetStrCopy(config_set_t *configSet, const char *key, char *value, int length)
{
    const char *valref = NULL;
    if (configGetStr(configSet, key, &valref)) {
        strncpy(value, valref, length);
        value[length - 1] = '\0';
        return 1;
    } else {
        value[0] = '\0';
        return 0;
    }
}

int configSetInt(config_set_t *configSet, const char *key, const int value)
{
    char tmp[12];
    snprintf(tmp, sizeof(tmp), "%d", value);
    return configSetStr(configSet, key, tmp);
}

int configGetInt(config_set_t *configSet, const char *key, int *value)
{
    const char *valref = NULL;
    if (configGetStr(configSet, key, &valref)) {
        *value = atoi(valref);
        return 1;
    } else {
        return 0;
    }
}

int configSetColor(config_set_t *configSet, const char *key, unsigned char *color)
{
    char tmp[8];
    snprintf(tmp, sizeof(tmp), "#%02X%02X%02X", color[0], color[1], color[2]);
    return configSetStr(configSet, key, tmp);
}

int configGetColor(config_set_t *configSet, const char *key, unsigned char *color)
{
    const char *valref = NULL;
    if (configGetStr(configSet, key, &valref)) {
        strToColor(valref, color);
        return 1;
    } else {
        return 0;
    }
}

int configRemoveKey(config_set_t *configSet, const char *key)
{
    if (!configKeyValidate(key))
        return 0;

    struct config_value_t *val = configSet->head;
    struct config_value_t *prev = NULL;

    while (val) {
        if (strncmp(val->key, key, sizeof(val->key)) == 0) {
            if (key[0] != '#')
                configSet->modified = 1;

            if (val == configSet->tail)
                configSet->tail = prev;

            val = val->next;
            if (prev) {
                free(prev->next);
                prev->next = val;
            } else {
                free(configSet->head);
                configSet->head = val;
            }
        } else {
            prev = val;
            val = val->next;
        }
    }

    return 1;
}

void configMerge(config_set_t *dest, const config_set_t *source)
{
    struct config_value_t *val;

    for (val = source->head; val != NULL; val = val->next) {
        configSetStr(dest, val->key, val->val);
    }
}

static int configReadLegacyIP(void)
{
    config_set_t *configSet;
    char temp[16];

    LOG("CONFIG: Attempting to read legacy IP configuration from %s\n", legacyNetConfigPath);
    
    int fd = openFile(legacyNetConfigPath, O_RDONLY);
    if (fd < 0) {
        LOG("CONFIG Error: Failed to open legacy IP config file %s\n", legacyNetConfigPath);
        return 0;
    }
    
    int size = getFileSize(fd);
    if (size <= 0 || size > 255) {
        LOG("CONFIG Error: Invalid file size for legacy IP config: %d\n", size);
        close(fd);
        return 0;
    }
    
    char ipconfig[256] = {0}; // Initialize to zeros for safety
    int bytesRead = read(fd, &ipconfig, size);
    close(fd);
    
    if (bytesRead != size) {
        LOG("CONFIG Error: Failed to read complete legacy IP config, read %d of %d bytes\n", bytesRead, size);
        return 0;
    }
    
    // Ensure null termination for string operations
    ipconfig[255] = '\0';
    
    // Initialize IP arrays to zeros for safety
    memset(ps2_ip, 0, sizeof(ps2_ip));
    memset(ps2_netmask, 0, sizeof(ps2_netmask));
    memset(ps2_gateway, 0, sizeof(ps2_gateway));
    
    int scanned = sscanf(ipconfig, "%d.%d.%d.%d %d.%d.%d.%d %d.%d.%d.%d", 
           &ps2_ip[0], &ps2_ip[1], &ps2_ip[2], &ps2_ip[3],
           &ps2_netmask[0], &ps2_netmask[1], &ps2_netmask[2], &ps2_netmask[3],
           &ps2_gateway[0], &ps2_gateway[1], &ps2_gateway[2], &ps2_gateway[3]);
           
    if (scanned != 12) {
        LOG("CONFIG Error: Failed to parse legacy IP config, scanned %d of 12 values\n", scanned);
        return 0;
    }

    // Validate IP values are in valid range (0-255)
    for (int i = 0; i < 4; i++) {
        if (ps2_ip[i] < 0 || ps2_ip[i] > 255 || 
            ps2_netmask[i] < 0 || ps2_netmask[i] > 255 || 
            ps2_gateway[i] < 0 || ps2_gateway[i] > 255) {
            LOG("CONFIG Error: Invalid IP value in legacy config\n");
            return 0;
        }
    }

    configSet = &configFiles[CONFIG_INDEX_NETWORK];
    if (!configSet) {
        LOG("CONFIG Error: Failed to get network config set\n");
        return 0;
    }

    // Safely format and store the IP addresses
    if (snprintf(temp, sizeof(temp), "%d.%d.%d.%d", ps2_ip[0], ps2_ip[1], ps2_ip[2], ps2_ip[3]) >= sizeof(temp)) {
        LOG("CONFIG Error: IP address buffer overflow\n");
        return 0;
    }
    configSetStr(configSet, CONFIG_NET_PS2_IP, temp);
    
    if (snprintf(temp, sizeof(temp), "%d.%d.%d.%d", ps2_netmask[0], ps2_netmask[1], ps2_netmask[2], ps2_netmask[3]) >= sizeof(temp)) {
        LOG("CONFIG Error: Netmask buffer overflow\n");
        return 0;
    }
    configSetStr(configSet, CONFIG_NET_PS2_NETM, temp);
    
    if (snprintf(temp, sizeof(temp), "%d.%d.%d.%d", ps2_gateway[0], ps2_gateway[1], ps2_gateway[2], ps2_gateway[3]) >= sizeof(temp)) {
        LOG("CONFIG Error: Gateway buffer overflow\n");
        return 0;
    }
    configSetStr(configSet, CONFIG_NET_PS2_GATEW, temp);
    
    // The legacy format has no setting for the DNS server, so duplicate the gateway address.
    configSetStr(configSet, CONFIG_NET_PS2_DNS, temp);
    
    LOG("CONFIG: Successfully read legacy IP configuration\n");
    return 1;
}

// dst has to have 5 bytes space
void configGetDiscIDBinary(config_set_t *configSet, void *dst)
{
    memset(dst, 0, 5);

    const char *gid = NULL;
    if (configGetStr(configSet, CONFIG_ITEM_DNAS, &gid)) {
        // convert from hex to binary
        char *cdst = dst;
        int p = 0;
        while (*gid && p < 10) {
            int dv = -1;

            while (dv < 0 && *gid) // skip spaces, etc
                dv = fromHex(*(gid++));

            if (dv < 0)
                break;

            *cdst = *cdst * 16 + dv;
            if ((++p & 1) == 0)
                cdst++;
        }
    }
}

static int configReadFileBuffer(file_buffer_t *fileBuffer, config_set_t *configSet)
{
    char *line;
    unsigned int lineno = 0;

    char prefix[CONFIG_KEY_NAME_LEN];
    memset(prefix, 0, sizeof(prefix));

    while (readFileBuffer(fileBuffer, &line)) {
        lineno++;

        char key[CONFIG_KEY_NAME_LEN], val[CONFIG_KEY_VALUE_LEN];
        memset(key, 0, sizeof(key));
        memset(val, 0, sizeof(val));

        if (splitAssignment(line, key, sizeof(key), val, sizeof(val))) {
            /* if the line does not start with whitespace,
             * the prefix ends and we have to reset it
             */
            if (!isWS(line[0]))
                memset(prefix, 0, sizeof(prefix));

            // insert config value
            if (prefix[0]) {
                // we have a prefix
                char composedKey[CONFIG_KEY_NAME_LEN];

                snprintf(composedKey, sizeof(composedKey), "%s_%s", prefix, key);
                configSetStr(configSet, composedKey, val);
            } else {
                configSetStr(configSet, key, val);
            }
        } else if (parsePrefix(line, prefix)) {
            // prefix is set, that's about it
        } else {
            LOG("CONFIG Malformed file '%s' line %d: '%s'\n", configSet->filename, lineno, line);
        }
    }
    configSet->modified = 0;
    return 1;
}

int configReadBuffer(config_set_t *configSet, const void *buffer, int size)
{
    int ret;
    
    if (!configSet) {
        LOG("CONFIG Error: NULL config set in configReadBuffer\n");
        return 0;
    }
    
    if (!buffer || size <= 0) {
        LOG("CONFIG Error: Invalid buffer or size in configReadBuffer\n");
        configSet->modified = 0;
        return 0;
    }
    
    file_buffer_t *fileBuffer = openFileBufferBuffer(0, buffer, size);
    if (!fileBuffer) {
        LOG("CONFIG Error: Failed to open file buffer in configReadBuffer\n");
        configSet->modified = 0;
        return 0;
    }

    ret = configReadFileBuffer(fileBuffer, configSet);
    closeFileBuffer(fileBuffer);
    return ret;

int configRead(config_set_t *configSet)
{
    int ret;
    
    if (!configSet) {
        LOG("CONFIG Error: NULL config set in configRead\n");
        return 0;
    }

int configWrite(config_set_t *configSet)
{
    if (!configSet) {
        LOG("CONFIG Error: NULL config set in configWrite\n");
        return 0;
    }

    if (!configSet->filename) {
        LOG("CONFIG Error: NULL filename in configWrite\n");
        return 0;
    }

    if (configSet->modified) {
        LOG("CONFIG: Writing configuration to %s\n", configSet->filename);
        file_buffer_t *fileBuffer = openFileBuffer(configSet->filename, O_WRONLY | O_CREAT | O_TRUNC, 0, 4096);
        if (!fileBuffer) {
            LOG("CONFIG Error: Failed to open file %s for writing\n", configSet->filename);
            return 0;
        }

        char line[512];
        int writeResult = 1;

        bgmMute();
        struct config_value_t *cur = configSet->head;
        while (cur && writeResult) {
            if ((cur->key[0] != '\0') && (cur->key[0] != '#')) {
                // Prevent buffer overflow
                if (snprintf(line, sizeof(line), "%s=%s\r\n", cur->key, cur->val) >= sizeof(line)) {
                    LOG("CONFIG Warning: Line truncated for key %s\n", cur->key);
                }
                
                size_t lineLen = strlen(line);
                if (writeFileBuffer(fileBuffer, line, lineLen) != lineLen) {
                    LOG("CONFIG Error: Failed to write to file %s\n", configSet->filename);
                    writeResult = 0;
                }
            }

            // and advance
            cur = cur->next;
        }

        closeFileBuffer(fileBuffer);
        
        if (writeResult) {
            configSet->modified = 0;
            LOG("CONFIG: Successfully wrote configuration to %s\n", configSet->filename);
        } else {
            LOG("CONFIG Error: Failed to write complete configuration to %s\n", configSet->filename);
        }
        
        bgmUnMute();
        return writeResult;
    }
    return 1;
}

int configGetStat(config_set_t *configSet, iox_stat_t *stat)
{
    return (fileXioGetStat(configSet->filename, stat) >= 0 ? 1 : 0);
}

void configClear(config_set_t *configSet)
{
    while (configSet->head) {
        struct config_value_t *cur = configSet->head;
        configSet->head = cur->next;

        free(cur);
    }

    configSet->head = NULL;
    configSet->tail = NULL;
    configSet->modified = 1;
}

int configReadMulti(int types)
{
    int result = 0, index;

    for (index = 0; index < CONFIG_INDEX_COUNT; index++) {
        config_set_t *configSet = &configFiles[index];

        if (configSet->type & types) {
            configClear(configSet);
            if (configRead(configSet))
                result |= configSet->type;
        }
    }

    // If the network configuration is to be loaded and one cannot be loaded, attempt to load from the legacy network config file.
    if ((types & CONFIG_NETWORK) && !(result & CONFIG_NETWORK))
        if (configReadLegacyIP())
            result |= CONFIG_NETWORK;

    return result;
}

int configWriteMulti(int types)
{
    int result = 0, index;

    for (index = 0; index < CONFIG_INDEX_COUNT; index++) {
        config_set_t *configSet = &configFiles[index];

        if (configSet->type & types)
            result += configWrite(configSet);
    }

    return result;
}

void configGetVMC(config_set_t *configSet, char *vmc, int length, int slot)
{
    char gkey[CONFIG_KEY_NAME_LEN];
    snprintf(gkey, sizeof(gkey), "%s_%d", CONFIG_ITEM_VMC, slot);
    configGetStrCopy(configSet, gkey, vmc, length);
}

void configSetVMC(config_set_t *configSet, const char *vmc, int slot)
{
    char gkey[CONFIG_KEY_NAME_LEN];
    if (vmc[0] == '\0') {
        configRemoveVMC(configSet, slot);
        return;
    }
    snprintf(gkey, sizeof(gkey), "%s_%d", CONFIG_ITEM_VMC, slot);
    configSetStr(configSet, gkey, vmc);
}

void configRemoveVMC(config_set_t *configSet, int slot)
{
    char gkey[CONFIG_KEY_NAME_LEN];
    snprintf(gkey, sizeof(gkey), "%s_%d", CONFIG_ITEM_VMC, slot);
    configRemoveKey(configSet, gkey);
}
