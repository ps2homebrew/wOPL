/*
 * Copyright (c) 2001-2003 Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * This file is part of the lwIP TCP/IP stack.
 *
 * Author: Adam Dunkels <adam@sics.se>
 *
 */
#ifndef __LWIP_IP_ADDR_H__
#define __LWIP_IP_ADDR_H__

#include "lwip/arch.h"

/** IP_ADDR_ can be used as a fixed IP address
 *  for the wildcard and the broadcast address
 */
#define IP_ADDR_ANY       ((struct ip_addr *)&ip_addr_any)
#define IP_ADDR_BROADCAST ((struct ip_addr *)&ip_addr_broadcast)

#define INADDR_NONE     ((u32_t)0xffffffff) /* 255.255.255.255 */
#define INADDR_LOOPBACK ((u32_t)0x7f000001) /* 127.0.0.1 */

/* Definitions of the bits in an Internet address integer.

   On subnets, host and network parts are found according to
   the subnet mask, not these masks.  */

#define IN_CLASSA(a)     ((((u32_t)(a)) & 0x80000000) == 0)
#define IN_CLASSA_NET    0xff000000
#define IN_CLASSA_NSHIFT 24
#define IN_CLASSA_HOST   (0xffffffff & ~IN_CLASSA_NET)
#define IN_CLASSA_MAX    128

#define IN_CLASSB(a)     ((((u32_t)(a)) & 0xc0000000) == 0x80000000)
#define IN_CLASSB_NET    0xffff0000
#define IN_CLASSB_NSHIFT 16
#define IN_CLASSB_HOST   (0xffffffff & ~IN_CLASSB_NET)
#define IN_CLASSB_MAX    65536

#define IN_CLASSC(a)     ((((u32_t)(a)) & 0xe0000000) == 0xc0000000)
#define IN_CLASSC_NET    0xffffff00
#define IN_CLASSC_NSHIFT 8
#define IN_CLASSC_HOST   (0xffffffff & ~IN_CLASSC_NET)

#define IN_CLASSD(a)     (((u32_t)(a)&0xf0000000) == 0xe0000000)
#define IN_CLASSD_NET    0xf0000000 /* These ones aren't really */
#define IN_CLASSD_NSHIFT 28         /* net and host fields, but */
#define IN_CLASSD_HOST   0x0fffffff /* routing needn't know.    */
#define IN_MULTICAST(a)  IN_CLASSD(a)

#define IN_EXPERIMENTAL(a) (((u32_t)(a)&0xf0000000) == 0xf0000000)
#define IN_BADCLASS(a)     (((u32_t)(a)&0xf0000000) == 0xf0000000)

#define IN_LOOPBACKNET 127 /* official! */

#ifdef PACK_STRUCT_USE_INCLUDES
#include "arch/bpstruct.h"
#endif
struct ip_addr
{
    PACK_STRUCT_FIELD(u32_t addr);
} PACK_STRUCT_STRUCT;
#ifdef PACK_STRUCT_USE_INCLUDES
#include "arch/epstruct.h"
#endif

/* For compatibility with BSD code */
struct in_addr
{
    u32_t s_addr;
};

extern const struct ip_addr ip_addr_any;
extern const struct ip_addr ip_addr_broadcast;

#define IP4_ADDR(ipaddr, a, b, c, d) (ipaddr)->addr = htonl(((u32_t)(a & 0xff) << 24) | ((u32_t)(b & 0xff) << 16) | \
                                                            ((u32_t)(c & 0xff) << 8) | (u32_t)(d & 0xff))

#define ip_addr_set(dest, src) (dest)->addr =           \
                                   ((src) == NULL ? 0 : \
                                                    ((struct ip_addr *)src)->addr)
#define ip_addr_maskcmp(addr1, addr2, mask) (((addr1)->addr &  \
                                              (mask)->addr) == \
                                             ((addr2)->addr &  \
                                              (mask)->addr))
#define ip_addr_cmp(addr1, addr2) ((addr1)->addr == (addr2)->addr)

#define ip_addr_isany(addr1) ((addr1) == NULL || (addr1)->addr == 0)

#define ip_addr_isbroadcast(addr1, mask) (((((addr1)->addr) & ~((mask)->addr)) == \
                                           (0xffffffff & ~((mask)->addr))) ||     \
                                          ((addr1)->addr == 0xffffffff) ||        \
                                          ((addr1)->addr == 0x00000000))

#define ip_addr_ismulticast(addr1) (((addr1)->addr & ntohl(0xf0000000)) == ntohl(0xe0000000))


#define ip_addr_debug_print(debug, ipaddr) LWIP_DEBUGF(debug, ("%u.%u.%u.%u",                                                   \
                                                               ipaddr ? (unsigned int)(ntohl((ipaddr)->addr) >> 24) & 0xff : 0, \
                                                               ipaddr ? (unsigned int)(ntohl((ipaddr)->addr) >> 16) & 0xff : 0, \
                                                               ipaddr ? (unsigned int)(ntohl((ipaddr)->addr) >> 8) & 0xff : 0,  \
                                                               ipaddr ? (unsigned int)ntohl((ipaddr)->addr) & 0xff : 0U))

/* cast to unsigned int, as it is used as argument to printf functions
 * which expect integer arguments */
#define ip4_addr1(ipaddr) ((unsigned int)(ntohl((ipaddr)->addr) >> 24) & 0xff)
#define ip4_addr2(ipaddr) ((unsigned int)(ntohl((ipaddr)->addr) >> 16) & 0xff)
#define ip4_addr3(ipaddr) ((unsigned int)(ntohl((ipaddr)->addr) >> 8) & 0xff)
#define ip4_addr4(ipaddr) ((unsigned int)(ntohl((ipaddr)->addr)) & 0xff)
#endif /* __LWIP_IP_ADDR_H__ */
